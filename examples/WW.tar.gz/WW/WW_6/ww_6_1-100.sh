#!/bin/sh

sop-gpu ww_6_1-100_equil.sop
sop-gpu ww_6_1-100_pull.sop

